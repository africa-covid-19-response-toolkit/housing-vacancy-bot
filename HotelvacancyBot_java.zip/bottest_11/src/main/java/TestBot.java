import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardRow;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.util.ArrayList;
import java.util.List;


public class TestBot extends TelegramLongPollingBot {
private  static int number;

public synchronized void sendMsg(Message message, String text)
{
SendMessage sm= new SendMessage();
sm.enableMarkdown(true);
sm.setChatId(message.getChatId().toString());
sm.setReplyToMessageId(message.getMessageId());
sm.setText(text);

try {
  execute(sm);


}
catch (TelegramApiException e) {
    e.printStackTrace();
}
}

public static  boolean isNumeric(String strNum)
{
    if(strNum==null)
    {
        return false;
    }
    try {
         number= Integer.parseInt(strNum);
    }
    catch (NumberFormatException nfe)
    {
        return false;
    }
    return true;
}

public void onUpdateReceived(Update update ) {
  System.out.println(update.getMessage().getText());
  System.out.println(update.getMessage().getFrom().getFirstName());

    Message receiveMsg = update.getMessage();
    String num =receiveMsg.getText();

    System.out.println(num);
   boolean retunnnum=isNumeric(num);
if(retunnnum && number >0 && number<200) {
     sendMsg(receiveMsg, num + " rooms available will be checked");

 }
else if(update.getMessage().getText().equals("Look Available Hotels"))
{
    long chat_id = update.getMessage().getChatId();
String[] hotels= {"Skylight", "Gihon","Ambassdor","Sheratoon","Pyramid","Monarch"};
    ReplyKeyboardMarkup keyboardMarkup= new ReplyKeyboardMarkup();
    List<KeyboardRow> keyboard= new ArrayList<>();
    KeyboardRow row= new KeyboardRow();
for(int i=0;i<hotels.length;i++) {

    row.add(hotels[i]);
    if((hotels.length/2)-1==i)
    {
        keyboard.add(row);
        row = new KeyboardRow();
    }
}
    keyboard.add(row);
    keyboardMarkup.setKeyboard(keyboard);

    SendMessage sm = new SendMessage();
    sm.setChatId(chat_id);
    sm.setReplyMarkup(keyboardMarkup);
    sm.enableMarkdown(true);

    sm.setChatId(chat_id);
    sm.setText("List of Hotels");

    try {
        execute(sm);


    } catch (TelegramApiException e) {
        e.printStackTrace();
    }

}
else if(update.getMessage().getText().equals("/start"))
{
    ReplyKeyboardMarkup keyboardMarkup= new ReplyKeyboardMarkup();
    List<KeyboardRow> keyboard= new ArrayList<>();
    KeyboardRow row= new KeyboardRow();
    row.add("Look Available Hotels");
    row.add("other Information");
    keyboard.add(row);

    keyboardMarkup.setKeyboard(keyboard);

   // String message_text = update.getMessage().getText();
    long chat_id = update.getMessage().getChatId();

    SendMessage sm= new SendMessage();
    sm.setChatId(chat_id);
    sm.setReplyMarkup(keyboardMarkup);
    sm.enableMarkdown(true);

    sm.setChatId(chat_id);
    sm.setReplyToMessageId(update.getMessage().getMessageId());
    sm.setText(" select from the Menu");
      try {
        execute(sm);


    }
    catch (TelegramApiException e) {
        e.printStackTrace();
    }


}
else
{
    sendMsg(receiveMsg,"Please Enter number of rooms available");
}



}



    public String getBotUsername() {
        return "AmanuelTest_bot. ";
    }

    public String getBotToken() {
        return "920924998:AAHs8vJnTZeozm2pH60lvTM8kuFOKpXun6k";
    }

}
